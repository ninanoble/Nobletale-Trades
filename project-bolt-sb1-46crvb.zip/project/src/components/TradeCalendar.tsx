import React from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from 'date-fns';
import type { Trade } from '../api/trades';

interface TradeCalendarProps {
  trades: Trade[];
  selectedDate?: Date;
  onSelectDate?: (date: Date) => void;
}

export default function TradeCalendar({ trades, selectedDate, onSelectDate }: TradeCalendarProps) {
  const today = new Date();
  const monthStart = startOfMonth(today);
  const monthEnd = endOfMonth(today);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const getTradesForDay = (date: Date) => 
    trades.filter(trade => isSameDay(new Date(trade.date), date));

  const getDayClass = (date: Date) => {
    const dayTrades = getTradesForDay(date);
    const isSelected = selectedDate && isSameDay(date, selectedDate);
    const baseClass = "h-10 w-10 rounded-full flex items-center justify-center cursor-pointer";
    
    if (dayTrades.length === 0) {
      return `${baseClass} hover:bg-gray-100 dark:hover:bg-gray-700`;
    }

    const profitableCount = dayTrades.filter(t => t.pl > 0).length;
    const lossCount = dayTrades.length - profitableCount;
    
    if (profitableCount > lossCount) {
      return `${baseClass} bg-green-100 dark:bg-green-900 hover:bg-green-200 dark:hover:bg-green-800 ${
        isSelected ? 'ring-2 ring-green-500' : ''
      }`;
    } else if (lossCount > profitableCount) {
      return `${baseClass} bg-red-100 dark:bg-red-900 hover:bg-red-200 dark:hover:bg-red-800 ${
        isSelected ? 'ring-2 ring-red-500' : ''
      }`;
    }
    
    return `${baseClass} bg-yellow-100 dark:bg-yellow-900 hover:bg-yellow-200 dark:hover:bg-yellow-800 ${
      isSelected ? 'ring-2 ring-yellow-500' : ''
    }`;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
          {format(today, 'MMMM yyyy')}
        </h2>
      </div>
      <div className="grid grid-cols-7 gap-1 mb-2">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-sm font-medium text-gray-500 dark:text-gray-400">
            {day}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {days.map(day => (
          <div
            key={day.toISOString()}
            className="aspect-square flex items-center justify-center"
            onClick={() => onSelectDate?.(day)}
          >
            <div className={getDayClass(day)}>
              <span className="text-sm dark:text-gray-200">
                {format(day, 'd')}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}