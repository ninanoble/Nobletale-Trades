import React from 'react';
import { useForm } from 'react-hook-form';
import { X } from 'lucide-react';
import toast from 'react-hot-toast';
import { createTrade } from '../api/trades';

interface TradeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TradeFormData {
  symbol: string;
  type: 'Long' | 'Short';
  entry: number;
  exit: number;
  quantity: number;
  notes: string;
}

export default function TradeModal({ isOpen, onClose }: TradeModalProps) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<TradeFormData>();

  const onSubmit = async (data: TradeFormData) => {
    try {
      await createTrade(data);
      toast.success('Trade added successfully');
      reset();
      onClose();
    } catch (error) {
      toast.error('Failed to add trade');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 w-full max-w-md relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-400 hover:text-gray-600"
        >
          <X className="w-5 h-5" />
        </button>
        
        <h2 className="text-xl font-semibold mb-6">Add New Trade</h2>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Symbol
            </label>
            <input
              {...register('symbol', { required: 'Symbol is required' })}
              className="w-full px-3 py-2 border rounded-lg focus:ring-1 focus:ring-indigo-500"
              placeholder="AAPL"
            />
            {errors.symbol && (
              <p className="text-red-500 text-sm mt-1">{errors.symbol.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Type
            </label>
            <select
              {...register('type', { required: 'Type is required' })}
              className="w-full px-3 py-2 border rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              <option value="Long">Long</option>
              <option value="Short">Short</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Entry Price
              </label>
              <input
                type="number"
                step="0.01"
                {...register('entry', { required: 'Entry price is required' })}
                className="w-full px-3 py-2 border rounded-lg focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Exit Price
              </label>
              <input
                type="number"
                step="0.01"
                {...register('exit', { required: 'Exit price is required' })}
                className="w-full px-3 py-2 border rounded-lg focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Quantity
            </label>
            <input
              type="number"
              {...register('quantity', { required: 'Quantity is required' })}
              className="w-full px-3 py-2 border rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes
            </label>
            <textarea
              {...register('notes')}
              className="w-full px-3 py-2 border rounded-lg focus:ring-1 focus:ring-indigo-500"
              rows={3}
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:text-gray-900"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Add Trade
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}