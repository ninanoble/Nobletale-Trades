import React from 'react';
import { PieChart } from 'lucide-react';

interface WinLossDistributionProps {
  wins: number;
  losses: number;
}

export default function WinLossDistribution({ wins, losses }: WinLossDistributionProps) {
  const total = wins + losses;
  const winPercentage = (wins / total) * 100;
  const lossPercentage = (losses / total) * 100;

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Win/Loss Distribution</h2>
        <PieChart className="w-5 h-5 text-gray-400 dark:text-gray-500" />
      </div>
      <div className="flex items-center justify-center">
        <div className="relative w-48 h-48">
          <svg className="w-full h-full" viewBox="0 0 100 100">
            {/* Background circle */}
            <circle
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke="#374151"
              strokeWidth="10"
              className="dark:stroke-gray-700"
            />
            
            {/* Win arc */}
            <circle
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke="#10B981"
              strokeWidth="10"
              strokeDasharray={`${winPercentage * 2.827} 282.7`}
              transform="rotate(-90 50 50)"
              className="dark:stroke-green-600"
            />
            
            {/* Center content */}
            <text
              x="50"
              y="45"
              textAnchor="middle"
              className="text-3xl font-bold fill-gray-900 dark:fill-white"
            >
              {Math.round(winPercentage)}%
            </text>
            <text
              x="50"
              y="65"
              textAnchor="middle"
              className="text-sm fill-gray-500 dark:fill-gray-400"
            >
              Win Rate
            </text>
          </svg>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mt-6">
        <div className="text-center">
          <div className="text-sm text-gray-500 dark:text-gray-400">Wins</div>
          <div className="text-xl font-semibold text-green-600 dark:text-green-500">{wins}</div>
        </div>
        <div className="text-center">
          <div className="text-sm text-gray-500 dark:text-gray-400">Losses</div>
          <div className="text-xl font-semibold text-red-600 dark:text-red-500">{losses}</div>
        </div>
      </div>
    </div>
  );
}