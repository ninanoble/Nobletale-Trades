import axios from 'axios';

const API_URL = 'http://localhost:3001/api';

export interface Trade {
  id: string;
  date: string;
  symbol: string;
  type: 'Long' | 'Short';
  entry: number;
  exit: number;
  quantity: number;
  pl: number;
  notes?: string;
}

export const fetchTrades = async (): Promise<Trade[]> => {
  try {
    const response = await axios.get(`${API_URL}/trades`);
    return response.data;
  } catch (error) {
    console.error('Error fetching trades:', error);
    return [];
  }
};

export const createTrade = async (tradeData: Omit<Trade, 'id' | 'date' | 'pl'>): Promise<Trade> => {
  try {
    const response = await axios.post(`${API_URL}/trades`, tradeData);
    return response.data;
  } catch (error) {
    console.error('Error creating trade:', error);
    throw error;
  }
};