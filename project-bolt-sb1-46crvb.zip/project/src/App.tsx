import React, { useState } from 'react';
import { Moon, Sun, LineChart, Activity, TrendingUp, DollarSign, Target } from 'lucide-react';
import { AreaChart } from '@tremor/react';
import { useQuery } from 'react-query';
import toast from 'react-hot-toast';
import { useTheme } from './context/ThemeContext';
import TradeModal from './components/TradeModal';
import StatCard from './components/StatCard';
import TradeCalendar from './components/TradeCalendar';
import WinLossDistribution from './components/WinLossDistribution';
import { fetchTrades } from './api/trades';

const performanceData = [
  { date: '2024-01', value: 2000 },
  { date: '2024-02', value: 4500 },
  { date: '2024-03', value: 3800 },
  { date: '2024-04', value: 6300 },
  { date: '2024-05', value: 5400 },
  { date: '2024-06', value: 8900 },
];

function App() {
  const { theme, toggleTheme } = useTheme();
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>();
  
  const { data: trades = [], isLoading, isError } = useQuery('trades', fetchTrades, {
    onError: () => {
      toast.error('Failed to load trades');
    }
  });

  const stats = {
    wins: trades.filter(t => t.pl > 0).length,
    losses: trades.filter(t => t.pl < 0).length,
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
      <header className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Activity className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Nobletale Trades</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                {theme === 'dark' ? (
                  <Sun className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                ) : (
                  <Moon className="w-5 h-5 text-gray-500" />
                )}
              </button>
              <button 
                onClick={() => setIsTradeModalOpen(true)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                New Trade
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard 
            title="Total P&L" 
            value="$24,685" 
            change="12.5" 
            icon={DollarSign} 
          />
          <StatCard 
            title="Win Rate" 
            value={`${((stats.wins / (stats.wins + stats.losses)) * 100).toFixed(1)}%`}
            change="4.2" 
            icon={Target} 
          />
          <StatCard 
            title="Avg. Trade" 
            value="$342" 
            change="2.1" 
            icon={TrendingUp} 
            isPositive={false}
          />
          <StatCard 
            title="Total Trades" 
            value={trades.length.toString()} 
            icon={Activity} 
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Performance</h2>
              <LineChart className="w-5 h-5 text-gray-400 dark:text-gray-500" />
            </div>
            <AreaChart
              className="h-64"
              data={performanceData}
              index="date"
              categories={["value"]}
              colors={["indigo"]}
              valueFormatter={(value) => `$${value.toLocaleString()}`}
              showLegend={false}
            />
          </div>
          <WinLossDistribution wins={stats.wins} losses={stats.losses} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <TradeCalendar 
            trades={trades}
            selectedDate={selectedDate}
            onSelectDate={setSelectedDate}
          />
          <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Trades</h2>
              <button className="text-sm text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300">
                View All
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-sm text-gray-500 dark:text-gray-400 border-b dark:border-gray-700">
                    <th className="pb-3 font-medium">Date</th>
                    <th className="pb-3 font-medium">Symbol</th>
                    <th className="pb-3 font-medium">Type</th>
                    <th className="pb-3 font-medium">Entry</th>
                    <th className="pb-3 font-medium">Exit</th>
                    <th className="pb-3 font-medium">P&L</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {isLoading ? (
                    <tr>
                      <td colSpan={6} className="text-center py-4 text-gray-500 dark:text-gray-400">Loading trades...</td>
                    </tr>
                  ) : isError ? (
                    <tr>
                      <td colSpan={6} className="text-center py-4 text-red-600 dark:text-red-400">Failed to load trades</td>
                    </tr>
                  ) : trades.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-4 text-gray-500 dark:text-gray-400">No trades found</td>
                    </tr>
                  ) : trades.map((trade, i) => (
                    <tr key={i} className="border-b dark:border-gray-700 last:border-b-0">
                      <td className="py-4 text-gray-900 dark:text-gray-100">
                        {new Date(trade.date).toLocaleDateString()}
                      </td>
                      <td className="py-4 font-medium text-gray-900 dark:text-gray-100">{trade.symbol}</td>
                      <td className="py-4">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          trade.type === 'Long' 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
                            : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                        }`}>
                          {trade.type}
                        </span>
                      </td>
                      <td className="py-4 text-gray-900 dark:text-gray-100">${trade.entry}</td>
                      <td className="py-4 text-gray-900 dark:text-gray-100">${trade.exit}</td>
                      <td className={`py-4 font-medium ${
                        trade.pl > 0 
                          ? 'text-green-600 dark:text-green-400' 
                          : 'text-red-600 dark:text-red-400'
                      }`}>
                        {trade.pl > 0 ? '+' : ''}{trade.pl}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>

      <TradeModal 
        isOpen={isTradeModalOpen} 
        onClose={() => setIsTradeModalOpen(false)} 
      />
    </div>
  );
}

export default App;